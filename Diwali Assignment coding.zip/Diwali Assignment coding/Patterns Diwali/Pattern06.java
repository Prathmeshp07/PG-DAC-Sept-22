

class Pattern06
{
	public static void main(String args[])
	{
		int i;
		int j;

		
		for(i=1 ; i<=5 ; i++)
		{
			for(j=i ; j>=1 ; j--)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	}
}

/*
output-
1
21
321
4321
54321
*/